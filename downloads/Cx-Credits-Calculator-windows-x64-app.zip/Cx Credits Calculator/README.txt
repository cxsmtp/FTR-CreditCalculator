Cx Credits Calculator

Open "Getting started.pdf" first.

Double-click "Cx Credits Calculator.exe". The first time, Windows may say it protected your PC: choose More info, then Run anyway.
The calculator opens in your browser at http://127.0.0.1:47317/. Your customers and reports are saved in cx-credits-calculator-data.json beside the program.
To stop it, close the window it runs in.
