@echo off
title Cx Credits Calculator
cd /d "%~dp0"
"%~dp0node\node.exe" "%~dp0cx-credits-calculator.mjs" %*
if errorlevel 1 pause
