Cx Credits Calculator

Open "Getting started.pdf" first.

Right-click "Start Cx Credits Calculator.command", choose Open, then Open again (only the first time).
The calculator opens in your browser at http://127.0.0.1:47317/. Your customers and reports are saved in cx-credits-calculator-data.json in this folder.
To stop it, close the window it runs in.
