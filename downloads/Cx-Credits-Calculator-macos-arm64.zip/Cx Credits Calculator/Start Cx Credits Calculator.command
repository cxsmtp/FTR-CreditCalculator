#!/bin/bash
# Cx Credits Calculator: runs from this folder, with the Node.js beside it.
cd "$(dirname "$0")" || exit 1
./node/node ./cx-credits-calculator.mjs "$@"
status=$?
[ $status -ne 0 ] && read -r -p "Press Enter to close. " _
exit $status
